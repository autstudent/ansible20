rm -rf ~/.ansible/collections/ansible_collections/acidonpe
rm ../../acidonpe-testing-1.0.0.tar.gz
